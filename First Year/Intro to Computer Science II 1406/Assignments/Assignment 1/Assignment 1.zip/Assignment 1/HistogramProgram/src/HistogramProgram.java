public class HistogramProgram
{
    public static void main(String[] args)
    {
        byte[] randomArray = new byte[100], countedArray = new byte[10];
        String[] asterisk = new String[10];
        byte num = 0;
        //int zero = 0, one = 0, two = 0, three = 0, four = 0, five = 0;
        //int six = 0, seven = 0, eight = 0, nine = 0;


        for ( int i=0; i < 100; i += 1)
        {
            randomArray[i] = (byte)(Math.random() * 10);
        }

        for (int i = 0; i < randomArray.length; i += 1)
        {
            //System.out.println(randomArray[i]);
            if (randomArray[i] == 0)
                countedArray[0] += 1;

            else if (randomArray[i] == 1)
                countedArray[1] += 1;

            else if (randomArray[i] == 2)
                countedArray[2] += 1;

            else if (randomArray[i] == 3)
                countedArray[3] += 1;

            else if (randomArray[i] == 4)
                countedArray[4] += 1;

            else if (randomArray[i] == 5)
                countedArray[5] += 1;

            else if (randomArray[i] == 6)
                countedArray[6] += 1;

            else if (randomArray[i] == 7)
                countedArray[7] += 1;

            else if (randomArray[i] == 8)
                countedArray[8] += 1;

            else if (randomArray[i] == 9)
                countedArray[9] += 1;

        }

        for (int i = 0; i < 10; i += 1 )
        {
            System.out.print(i + " |");

            for (int j = 0; j < countedArray[i]; j += 1)
            {
                System.out.print("*");
            }

            System.out.println();
        }

    }
}
