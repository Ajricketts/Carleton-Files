public class ImageProgram
{
    public static void main(String[] args)
    {

        boolean[][] bool = new boolean[10][10];
        int rand, horizontalCount, horizontalTemp = 0, verticalTemp = 0, verticalCount, horizontalLongest = 0;
        int verticalLongest = 0;
        char replaceTrue = 'O';
        String replaceFalse = ".";

        for (int i = 0; i < 10; i += 1)
        {

            for (int j = 0; j < 10; j += 1)
            {
                rand = (int)(Math.random() * 2);

                if (rand == 1)
                    bool[i][j] = true;
                else
                    bool[i][j] = false;

            }


        }

        for (int i = 0; i < 10; i += 1)
        {
            horizontalCount = 1;
            for (int j = 0; j < 10; j += 1)
            {

                if (bool[i][j])
                    System.out.print(replaceTrue);

                else
                    System.out.print(replaceFalse);

                if (j < 9)
                {
                    if (bool[i][j] == bool[i][j + 1] && (bool[i][j]))
                        horizontalCount += 1;

                    else if (bool[i][j])
                        horizontalCount = 1;


                }

                if (horizontalCount >= horizontalTemp)
                    horizontalTemp = horizontalCount;

            }

            System.out.println();


            if (horizontalTemp >= horizontalLongest)
                horizontalLongest = horizontalTemp;

            //System.out.print("Count = " + verticalCount + "   ");
            //System.out.print("Longest = " + longest + "   ");

        }


        for (int i = 0; i < 10; i += 1)
        {
            verticalCount = 1;
            for (int j = 0; j < 10; j += 1)

                if (j < 9)
                {
                    if (bool[j][i] == bool[j + 1][i] && (bool[j][i]))
                        verticalCount += 1;

                    else if (bool[j][i])
                        verticalCount = 1;


                }

            if (verticalCount >= verticalTemp)
                verticalTemp = verticalCount;

            if (verticalTemp >= verticalLongest)
                verticalLongest = verticalTemp;

            System.out.println(verticalTemp);

        }

        System.out.println("The longest horizontal sequence is " + horizontalLongest);
        System.out.println("The longest vertical sequence is " + verticalLongest);
    }
}

