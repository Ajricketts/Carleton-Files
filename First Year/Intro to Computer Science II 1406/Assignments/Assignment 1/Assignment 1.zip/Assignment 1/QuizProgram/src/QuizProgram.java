import java.util.Scanner;


public class QuizProgram
{
    public static void main(String[] args)
    {

        // Initialize the variables.
        int num1 =  0, num2 = 0, answer;
        boolean bool = true;
        int count = 0, answer_recieved, correct = 0, wrong = 0, rand;

        // Generate new questions 10 times.
        while (count < 10)
        {
            // Randomize the 2 numbers being added or subtracted. The first number is from 0-99 and the second number
            //  is from 0 to the first number.

            //Check to see if this really randomizes from 0 to 50 or if it does 0-49.9999
            num1= (int)(Math.random() * 99);
            num2 = (int)(Math.random() * num1);
            rand = (int)(Math.random() * 2);


            // Switch between addition and subtraction
            if (rand == 0)
            {
                System.out.print("\nWhat is the answer to " + num1 + " + " + num2 + " = ");
                answer = num1 + num2;
                //bool = false;
            }
            else {
                System.out.print("\nWhat is the answer to " + num1 + " - " + num2 + " = ");
                answer = num1 - num2;
                //bool = !bool;
            }

            answer_recieved = new Scanner(System.in).nextInt();

            // If it is the right answer display this message.
            if (answer_recieved == answer)
            {
                System.out.println("You are correct!");
                correct += 1;
            }

            // If it is the wrong answer display this message.
            else {
                System.out.println("Sorry, the correct answer is " + answer);
                wrong += 1;
            }

            count += 1;

        }

        // Display the test mark the user got.
        System.out.println("You got " + (correct * 10) +"% on the quiz.");


    }
}