public class BoxOffice {
    Theatre theatreA, theatreB;
    Movie bestMovie;

   /* Constructors */

   public BoxOffice(int capacity1, int capacity2) {
        theatreA = new Theatre(capacity1);
        theatreB = new Theatre(capacity2);
        bestMovie = new Movie("None");
    }

    /* Methods */

    public void openMovie(String m, Theatre t) {
        if(t.equals(theatreA)) {
            theatreA.moviePlaying = new Movie(m);
            theatreA.seatsSold = 0;
        }
        else{
            theatreB.moviePlaying = new Movie(m);
            theatreB.seatsSold = 0;
        }
    }

    public void sellTicket(Patron p, String m){
        if (m.equals(theatreA.moviePlaying.title) || m.equals(theatreB.moviePlaying.title))
        {
            if (theatreA.moviePlaying.title.equals(m)) {
                if (theatreA.seatsSold < theatreA.capacity)
                {
                    p.ticket = new Ticket(theatreA);
                    theatreA.seatsSold += 1;
                    if (p.age < 12)
                        theatreA.moviePlaying.earnings += 6.25;
                    else if (p.age > 65)
                        theatreA.moviePlaying.earnings += 5.75;
                    else
                        theatreA.moviePlaying.earnings += 12.50;

                }
            }
            else if (theatreB.moviePlaying.title.equals(m)){
                if (theatreB.seatsSold < theatreB.capacity)
                {
                    p.ticket = new Ticket(theatreB);
                    theatreB.seatsSold += 1;
                    if (p.age < 12)
                        theatreB.moviePlaying.earnings += 6.25;
                    else if (p.age > 65)
                        theatreB.moviePlaying.earnings += 5.75;

                    else
                        theatreB.moviePlaying.earnings += 12.50;
                }
            }
        }
        else
            System.out.println("Movie is not currently playing");

    }

    public void returnTicket(Patron p) {
        if (p.ticket == null)
            System.out.println("Patron does not have a ticket.");
        else {
            if (p.ticket.theatre.moviePlaying.title.equals(theatreA.moviePlaying.title)) {
                theatreA.seatsSold -= 1;
                p.ticket = null;

                if (p.age < 12)
                    theatreA.moviePlaying.earnings -= 6.25;
                else if (p.age > 65)
                    theatreA.moviePlaying.earnings -= 5.75;

                else
                    theatreA.moviePlaying.earnings -= 12.50;
            }
            else {
                theatreB.seatsSold -= 1;
                p.ticket = null;

                if (p.age < 12)
                    theatreB.moviePlaying.earnings -= 6.25;
                else if (p.age > 65)
                    theatreB.moviePlaying.earnings -= 5.75;
                else
                    theatreB.moviePlaying.earnings -= 12.50;

            }
        }
    }

    public Movie bestMovie(){

        if (bestMovie.hasMadeMore(theatreA.moviePlaying, theatreB.moviePlaying))
            return bestMovie;
        else if (theatreA.moviePlaying.hasMadeMore(bestMovie, theatreB.moviePlaying))
            return theatreA.moviePlaying;
        else if (theatreB.moviePlaying.hasMadeMore(bestMovie, theatreA.moviePlaying))
            return theatreB.moviePlaying;
        else return null;
    }

}
