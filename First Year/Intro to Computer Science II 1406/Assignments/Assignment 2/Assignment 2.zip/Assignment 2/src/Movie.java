public class Movie
{
    String title;
    double earnings;

    public Movie(String t) {
        title = t;
        earnings = 0;
    }

    public boolean hasMadeMore(Movie x, Movie y)
    {
        if (x != null)
            return (this.earnings > x.earnings) && (this.earnings >y.earnings);
        else
            return false;
    }
}
