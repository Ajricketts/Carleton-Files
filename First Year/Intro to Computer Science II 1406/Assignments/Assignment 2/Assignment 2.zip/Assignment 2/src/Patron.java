public class Patron {
    int age;
    Ticket ticket;

    public Patron(int a) {
        age = a;
        ticket = null;
    }

}
