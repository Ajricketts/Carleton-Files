public class Theatre {
    int capacity, seatsSold;
    Movie moviePlaying;

    public Theatre(){
        capacity = 0;
        seatsSold = 0;
        moviePlaying = null;

    }

    public Theatre(int c) {
        capacity = c;
        seatsSold = 0;
        moviePlaying = null;
    }

    public boolean isFull() {
        if (seatsSold == capacity) {
            System.out.println("Movie is sold out");
            return true;
        }
        else
            return false;
    }
}
