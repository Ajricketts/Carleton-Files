public class Ticket {
    Theatre theatre;
    public Ticket(Theatre t) {theatre = t;}
}
