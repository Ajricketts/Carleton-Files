public class Driver {
    String license, name, street, city, province;
    Driver DriverA;
    /* Constructors */

    public Driver(String License, String Name, String Street, String City, String Province) {
        license = License;
        name = Name;
        street = Street;
        city = City;
        province = Province;
    }

    public Driver() {
        this("L0000-00000-00000", "John Doe", "12 Elm St.", "Ottawa", "ON");
    }

    @Override
    public String toString() {
        return this.license + " " + this.name + " living at " + this.street + ", " + this.city + ", " + this.province;
    }
}
