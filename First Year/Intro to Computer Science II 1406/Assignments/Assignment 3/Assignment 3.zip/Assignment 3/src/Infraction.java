import java.util.Date;

public class Infraction {
    float amount;
    String description;
    boolean outstanding;
    Driver driver;
    Date dateIssued;

    public Infraction(float Amount, String Description, Date DateIssued) {
        amount = Amount;
        description = Description;
        dateIssued = DateIssued;
        outstanding = true;
        driver = null;
    }

    public Infraction() {
        this(0, "N/A", null);
    }

    @Override
    public String toString() {
        String date = String.format("%tc", this.dateIssued), paid = "[OUTSTANDING]";
        if (!this.outstanding)
            paid = "[PAID IN FULL]";
        return "$" + this.amount + " Infraction on " + date + " " + paid;
    }

    public void pay() {
        this.outstanding = false;
    }
}
