public class Vehicle {
    String make, model, color, plate;
    int year;
    boolean reportedStolen;
    Driver owner;

    public Vehicle(String Make, String Model, int Year, String Color, String Plate) {
        make = Make;
        model = Model;
        year = Year;
        color = Color;
        plate = Plate;
        reportedStolen = false;
        owner = null;
    }

    public Vehicle() {
        this("No make", "No model", 0000, "No colour", "A1A1A1");
    }

    @Override
    public String toString() {
        return "A " + this.color + " " + this.year + " " + this.make + " " + this.model + " with plate " + this.plate;
    }
}
