import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.event.*;

public class AlarmApp extends Application {

    public void start(Stage primaryStage) {
        Pane aPane = new Pane();

        TimePane cPane = new TimePane("Current Time", "01:54:16 PM");
        cPane.relocate(230,10);
        cPane.setPrefSize(200,40);

        TimePane alPane = new TimePane("Alarm Time", "10:30:00 AM");
        alPane.relocate(230,60);
        alPane.setPrefSize(200,40);

        RemainingTimePane rtime = new RemainingTimePane("Remaining Time", "00:00:00");
        rtime.relocate(10,10);
        rtime.setPrefSize(200, 90);

        ButtonPane buttons = new ButtonPane("New Alarm", "Edit", "Delete");
        buttons.relocate(10,150);

        ToggleGroup toggle = new ToggleGroup();
        RadioButton on = new RadioButton("ON");
        on.relocate(310,150);
        on.setPrefSize(50, 30);
        on.setToggleGroup(toggle);

        RadioButton off = new RadioButton("OFF");
        off.relocate(360,150);
        off.setPrefSize(50, 30);
        off.setToggleGroup(toggle);

        ObservableList<String> options = FXCollections.observableArrayList("Weekday", "Saturday", "Sunday");
        ComboBox selectAlarm = new ComboBox(options);
        selectAlarm.setPromptText("Select Alarm");
        selectAlarm.setPrefSize(410,30);
        selectAlarm.relocate(10,110);

        aPane.getChildren().addAll(cPane, alPane, buttons, off, on, selectAlarm, rtime);
        primaryStage.setTitle("Alarm App");
        primaryStage.setResizable(false);
        primaryStage.setScene(new Scene(aPane, 430, 190));
        primaryStage.show();
    }

    public static void main(String[] args) {launch(args);}
}
