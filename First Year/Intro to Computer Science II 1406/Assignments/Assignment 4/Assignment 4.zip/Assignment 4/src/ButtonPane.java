import javafx.scene.control.Button;
import javafx.scene.layout.Pane;

public class ButtonPane extends Pane {
    public ButtonPane(String newAlarmTitle, String newEditButtonTitle, String newDeleteButtonTitle) {
        Pane buttonpane = new Pane();

        Button newAlarm = new Button(newAlarmTitle);
        newAlarm.setPrefSize(100, 30);
        newAlarm.setStyle("-fx-font: 12 arial; -fx-base: whitesmoke; -fx-text-fill: rgb(0,0,0);");

        Button edit = new Button(newEditButtonTitle);
        edit.setPrefSize(80, 30);
        edit.relocate(110,0);
        edit.setStyle("-fx-font: 12 arial; -fx-base: whitesmoke; -fx-text-fill: rgb(0,0,0);");

        Button delete = new Button(newDeleteButtonTitle);
        delete.relocate(200, 0);
        delete.setPrefSize(80, 30);
        delete.setStyle("-fx-font: 12 arial; -fx-base: whitesmoke; -fx-text-fill: rgb(0,0,0);");

        buttonpane.getChildren().addAll(newAlarm, edit, delete);
        getChildren().addAll(buttonpane);
    }
}
