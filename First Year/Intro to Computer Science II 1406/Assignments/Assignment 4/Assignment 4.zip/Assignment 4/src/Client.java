import java.util.*;

public abstract class Client {
    private static final int MAX_POLICIES_PER_CLIENT = 10;

    private static int NEXT_CLIENT_ID = 1;

    private   String        name;
    private   int           id;
    protected Policy[]      policies;
    protected int           numPolicies;

    public Client(String n) {
        name = n;
        id = NEXT_CLIENT_ID++;
        policies = new Policy[MAX_POLICIES_PER_CLIENT];
        numPolicies = 0;
    }

    public String getName() { return name; }
    public int getId() { return id; }
    public Policy[] getPolicies() { return policies; }
    public int getNumPolicies() { return numPolicies; }

    public String toString() {
        return this.getClass().getName() + String.format(": %06d amount: %s", id, name);
    }

    public float totalCoverage() {
        float total = 0;
        for (int i = 0; i < numPolicies; i++) {
            total += policies[i].amount;
        }
        return total;
    }

    public Policy addPolicy(Policy p) {
        if (numPolicies < MAX_POLICIES_PER_CLIENT) {
            policies[numPolicies] = p;
            numPolicies ++;
            return p;
        }
        else
            return null;
    }

    public Policy openPolicyFor(float amt) {return addPolicy(new Policy(amt));}

    public Policy openPolicyFor(float amt, float rate) {return addPolicy(new DepreciatingPolicy(amt, rate));}

    public Policy openPolicyFor(float amt, Date expire) {return addPolicy(new ExpiringPolicy(amt, expire));}

    public Policy getPolicy(int polNum) {
        for (int i = 0; i < numPolicies; i++) {
            if (policies[i].getPolicyNumber() == polNum) {
                return policies[i];
            }
        }
        return null;
    }

    public boolean cancelPolicy(int polNum) {
        boolean found = false;
        for (int i = 0; i < numPolicies - 1; i++) {
            if (policies[i].getPolicyNumber() == polNum) {
                policies[i] = null;
                found = true;
                numPolicies--;
            }
        }

        for (int j = 0; j < policies.length - 1; j++) {
            if (policies[j] == null && policies[j + 1] != null) {
                policies[j] = policies[numPolicies];
                policies[numPolicies] = null;
            }
        }

        return found;
    }

    public abstract float makeClaim(int polNum);

}