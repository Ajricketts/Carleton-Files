public class CompanyClient extends Client {

    public CompanyClient(String s) {super(s);}

    @Override
    public float makeClaim(int polNum) {
        if (getPolicy(polNum) != null) {
            return getPolicy(polNum).handleClaim();
        }

        else
            return 0;
    }
}
