public class DepreciatingPolicy extends Policy {

    private float rate;

    public DepreciatingPolicy(float amount, float r) {
        super(amount);
        rate = r;
    }

    public float getRate() {return rate;}

    @Override
    public String toString() {
        return "Depreciating" + super.toString() + " rate: " + (rate * 100) + "%";
    }

    public boolean isExpired(){return getAmount() < 0.01;}

    public void depreciate() {super.amount -= super.amount * rate;}

    public float handleClaim() {
        float tempAmt = amount;
        depreciate();
        return tempAmt;
    }
}
