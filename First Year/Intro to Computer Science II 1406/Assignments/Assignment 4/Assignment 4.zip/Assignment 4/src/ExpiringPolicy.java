import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class ExpiringPolicy extends Policy {
    private Date expiryDate;
    SimpleDateFormat dateFormatter = new SimpleDateFormat("MMMM dd, yyyy (hh:mma)");
    SimpleDateFormat dateCheck = new SimpleDateFormat("MM,dd,yyyy");
    String result;

    public ExpiringPolicy(float a, Date exDate) {
        super(a);
        expiryDate = exDate;
    }

    public ExpiringPolicy(float a) {
        super(a);
        GregorianCalendar aCalendar = new GregorianCalendar();
        aCalendar.add(Calendar.YEAR, 1);
        expiryDate = aCalendar.getTime();
    }

    public Date getExpiryDate() {return expiryDate;}

    @Override
    public String toString() {
        GregorianCalendar aCalendar = new GregorianCalendar();

        if (aCalendar.after(expiryDate)) {
            result = dateFormatter.format(expiryDate);
            return "Expiring" + super.toString() + " expired on: " + result;
        }

        else {
            result = dateFormatter.format(expiryDate);
            return "Expiring" + super.toString() + " expires: " + result;
        }
    }

    public boolean isExpired() {
        Date checkCalendar = new Date();
        if (checkCalendar.after(expiryDate) || dateCheck.format(checkCalendar).equals(dateCheck.format(expiryDate)))
            return true;
        else
            return false;


    }

    public float handleClaim() {
        if (!isExpired())
            return amount;
        else
            return 0;
    }
}
