public class IndividualClient extends Client {

    public IndividualClient(String s) {super(s);}

    public float makeClaim(int polNum) {
        for (int i = 0; i < numPolicies; i++) {
            if (policies[i].getPolicyNumber() == polNum && policies[i].isExpired())
                return 0;
            else if (policies[i].getPolicyNumber() == polNum) {
                if (policies[i] instanceof DepreciatingPolicy) {
                    policies[i].handleClaim();
                    return policies[i].getAmount();
                }


                else if (!(policies[i] instanceof ExpiringPolicy)) {
                    float temp = policies[i].getAmount();
                    cancelPolicy(polNum);
                    return temp;
                }

                else
                    return policies[i].getAmount();
            }

        }

        return 0;
    }
}
