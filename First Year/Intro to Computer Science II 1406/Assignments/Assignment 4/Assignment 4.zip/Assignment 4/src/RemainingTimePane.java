import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

public class RemainingTimePane extends Pane{
    public RemainingTimePane(String Title, String Time) {
        Pane innerPane = new Pane();
        innerPane.setStyle("-fx-background-color: white;\n" +
                "  -fx-border-color: gray;  -fx-padding: 4 4;");

        Label remainingTime = new Label(Time);
        remainingTime.setStyle("-fx-font: 48 arial; -fx-text-fill: darkgreen");
        remainingTime.relocate(22,20);
        innerPane.getChildren().addAll(remainingTime);

        Label titleLabel = new Label();
        titleLabel.setText(Title);
        titleLabel.setStyle("-fx-background-color: white; -fx-translate-y: -8; -fx-translate-x: 10;");
        getChildren().addAll(innerPane,titleLabel);
    }
}
