import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.geometry.Pos;

public class TimePane extends Pane {
    public TimePane(String Title, String time) {
        Pane innerPane = new Pane();
        innerPane.setStyle("-fx-background-color: white;\n" +
                "  -fx-border-color: gray;  -fx-padding: 4 4;");

        TextField timeField = new TextField();
        timeField.setPrefSize(190, 25);
        timeField.relocate(5,10);
        timeField.setAlignment(Pos.CENTER_RIGHT);
        timeField.setEditable(false);
        timeField.setText(time);
        innerPane.getChildren().addAll(timeField);

        Label titleLabel = new Label();     // This is the title to be placed onto the border
        titleLabel.setText(Title);          // Incoming constructor parameter
        titleLabel.setStyle("-fx-background-color: white; -fx-translate-y: -8; -fx-translate-x: 10;");
        innerPane.setPrefSize(200,40);
        getChildren().addAll(innerPane, titleLabel);
    }
}
