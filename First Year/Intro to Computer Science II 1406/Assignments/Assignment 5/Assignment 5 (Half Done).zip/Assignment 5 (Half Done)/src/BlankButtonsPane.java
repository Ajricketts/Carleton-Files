import javafx.scene.control.Button;
import javafx.geometry.Insets;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;


public class BlankButtonsPane extends Pane{

    public BlankButtonsPane() {
        GridPane aPane = new GridPane();
        aPane.setHgap(1);
        aPane.setVgap(1);

        for (int row = 1; row <=4; row++) {
            for (int col = 1; col <=4; col++) {

                Button b = new Button();

                b.setPrefHeight(187);
                b.setPrefWidth(187);
                b.setPadding(new Insets(0,0,0,0));
                b.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("BLANK.png"))));

                aPane.add(b, col, row);
            }
        }
        //aPane.setPadding(new Insets(10,10,10,10));
        getChildren().addAll(aPane);
    }
}
