import javafx.geometry.Insets;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.control.Button;

public class SceneryButtonsPane extends Pane {

    private Button[][] buttonArray = new Button[4][4];

    public SceneryButtonsPane() {
        GridPane aPane = new GridPane();
        aPane.setHgap(1);
        aPane.setVgap(1);

        Button b1 = new Button();
        b1.setPrefHeight(187);
        b1.setPrefWidth(187);
        b1.setPadding(new Insets(0,0,0,0));
        b1.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_00.png"))));
        aPane.add(b1,1,1);
        buttonArray[0][0] = b1;

        Button b2 = new Button();
        b2.setPrefHeight(187);
        b2.setPrefWidth(187);
        b2.setPadding(new Insets(0,0,0,0));
        b2.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_01.png"))));
        aPane.add(b2,2,1);
        buttonArray[0][1] = b2;

        Button b3 = new Button();
        b3.setPrefHeight(187);
        b3.setPrefWidth(187);
        b3.setPadding(new Insets(0,0,0,0));
        b3.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_02.png"))));
        aPane.add(b3,3,1);
        buttonArray[0][2] = b3;

        Button b4 = new Button();
        b4.setPrefHeight(187);
        b4.setPrefWidth(187);
        b4.setPadding(new Insets(0,0,0,0));
        b4.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_03.png"))));
        aPane.add(b4,4,1);
        buttonArray[0][3] = b4;

        Button b5 = new Button();
        b5.setPrefHeight(187);
        b5.setPrefWidth(187);
        b5.setPadding(new Insets(0,0,0,0));
        b5.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_10.png"))));
        aPane.add(b5,1,2);
        buttonArray[1][0] = b5;

        Button b6 = new Button();
        b6.setPrefHeight(187);
        b6.setPrefWidth(187);
        b6.setPadding(new Insets(0,0,0,0));
        b6.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_11.png"))));
        aPane.add(b6,2,2);
        buttonArray[1][1] = b6;

        Button b7 = new Button();
        b7.setPrefHeight(187);
        b7.setPrefWidth(187);
        b7.setPadding(new Insets(0,0,0,0));
        b7.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_12.png"))));
        aPane.add(b7,3,2);
        buttonArray[1][2] = b7;

        Button b8 = new Button();
        b8.setPrefHeight(187);
        b8.setPrefWidth(187);
        b8.setPadding(new Insets(0,0,0,0));
        b8.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_13.png"))));
        aPane.add(b8,4,2);
        buttonArray[1][3] = b8;

        Button b9 = new Button();
        b9.setPrefHeight(187);
        b9.setPrefWidth(187);
        b9.setPadding(new Insets(0,0,0,0));
        b9.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_20.png"))));
        aPane.add(b9,1,3);
        buttonArray[2][0] = b9;

        Button b10 = new Button();
        b10.setPrefHeight(187);
        b10.setPrefWidth(187);
        b10.setPadding(new Insets(0,0,0,0));
        b10.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_21.png"))));
        aPane.add(b10,2,3);
        buttonArray[2][1] = b10;

        Button b11 = new Button();
        b11.setPrefHeight(187);
        b11.setPrefWidth(187);
        b11.setPadding(new Insets(0,0,0,0));
        b11.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_22.png"))));
        aPane.add(b11,3,3);
        buttonArray[3][2] = b11;

        Button b12 = new Button();
        b12.setPrefHeight(187);
        b12.setPrefWidth(187);
        b12.setPadding(new Insets(0,0,0,0));
        b12.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_23.png"))));
        aPane.add(b12,4,3);
        buttonArray[2][3] = b12;

        Button b13 = new Button();
        b13.setPrefHeight(187);
        b13.setPrefWidth(187);
        b13.setPadding(new Insets(0,0,0,0));
        b13.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_30.png"))));
        aPane.add(b13,1,4);
        buttonArray[3][0] = b13;

        Button b14 = new Button();
        b14.setPrefHeight(187);
        b14.setPrefWidth(187);
        b14.setPadding(new Insets(0,0,0,0));
        b14.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_31.png"))));
        aPane.add(b14,2,4);
        buttonArray[3][1] = b14;

        Button b15 = new Button();
        b15.setPrefHeight(187);
        b15.setPrefWidth(187);
        b15.setPadding(new Insets(0,0,0,0));
        b15.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_32.png"))));
        aPane.add(b15,3,4);
        buttonArray[3][2] = b15;

        Button b16 = new Button();
        b16.setPrefHeight(187);
        b16.setPrefWidth(187);
        b16.setPadding(new Insets(0,0,0,0));
        b16.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_33.png"))));
        aPane.add(b16,4,4);
        buttonArray[3][3] = b16;


        getChildren().addAll(aPane);
    }
    public Button[][] getButtonArray() {return buttonArray;}
}
