import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import java.util.Timer;
import java.util.TimerTask;

public class SidePane extends Pane {
    private Button start;
    private TextField timer;
    private ListView picList;
    private Label time, fullPic;
    public String pets = "Pets", scenery = "Scenery", lego = "Lego", numbers = "Numbers";

    public SidePane() {
        Pane aPane = new Pane();

        fullPic = new Label();
        fullPic.setPrefSize(187, 187);
        fullPic.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("BLANK.png"))));
        fullPic.setPadding(new Insets(0,10,10,10));


        String[] list = {pets, scenery, lego, numbers};
        picList = new ListView<String>();
        picList.setItems(FXCollections.observableArrayList(list));
        picList.setPrefSize(177, 147);
        picList.relocate(15,197);

        start = new Button("Start");
        start.setStyle("-fx-text-fill: WHITE; -fx-base: DARKGREEN");
        start.setPrefSize(187, 25);
        start.setMaxSize(187,25);
        start.setMinSize(187,25);
        //start.setPadding(new Insets(10,10,10,10));
        start.relocate(10, 354);

        time = new Label("Time:");
        time.relocate(10,394);
        time.setStyle("-fx-font: 11 arial; -fx-text-fill: rgb(0,0,0);");

        timer = new TextField();
        timer.setPrefSize(110, 25);
        timer.relocate(80,390);

        aPane.getChildren().addAll(fullPic,picList,start, time, timer);
        getChildren().addAll(aPane);

    }

    public Button getStart() {return start;}
    public ListView getPicList() {return picList;}
    public Label getTime() {return time;}
    public Label getFullPic() {return fullPic;}
    public TextField getTimer() {return timer;}
}
