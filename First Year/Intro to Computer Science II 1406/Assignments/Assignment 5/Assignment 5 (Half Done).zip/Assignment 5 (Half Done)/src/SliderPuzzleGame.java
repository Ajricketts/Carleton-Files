import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.Duration;


public class SliderPuzzleGame extends Application {
    public Timeline updateTimer;
    public void start(Stage primaryStage) {
        GridPane aPane = new GridPane();
        SliderPuzzleGameView1 view = new SliderPuzzleGameView1();
        aPane.getChildren().addAll(view);

        updateTimer = new Timeline(new KeyFrame(Duration.millis(1000),
                new EventHandler<ActionEvent>() {
                    public void handle(ActionEvent event) {
                        // FILL IN YOUR CODE HERE THAT WILL GET CALLED ONCE PER SEC.
                        view.getSide().getTimer().setText(updateTimer.toString());
                    }
                }));
        updateTimer.setCycleCount(Timeline.INDEFINITE);


        primaryStage.setTitle("Slider Puzzle Game");
        primaryStage.setScene(new Scene(aPane, 965,768));
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    //public Timeline getUpdateTimer() {return updateTimer;}
}
