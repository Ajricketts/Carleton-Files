import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;

import java.util.concurrent.ThreadLocalRandom;

public class SliderPuzzleGameView1 extends Pane{
    private String text;
    private SidePane side;
    private int randomRow, randomCol, row, col;
    private Pane pane;

    public SliderPuzzleGameView1() {
        GridPane pane = new GridPane();

        BlankButtonsPane buttons = new BlankButtonsPane();
        pane.add(buttons,0,0,1,4);
        //LegoButtonsPane buttons = new LegoButtonsPane();
        //NumbersButtonsPane buttons = new NumbersButtonsPane();


        side = new SidePane();
        pane.add(side,1,1);
        pane.setPadding(new Insets(10,10,10,10));

        side.getPicList().setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                text = side.getPicList().getSelectionModel().getSelectedItems().toString();

                if (text.equals("[" + side.pets + "]")) {
                    side.getFullPic().setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Pets_Thumbnail.png"))));
                }

                else if (text.equals("[" + side.scenery + "]")) {
                    side.getFullPic().setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_Thumbnail.png"))));
                }

                else if (text.equals("[" + side.lego + "]")) {
                    side.getFullPic().setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Lego_Thumbnail.png"))));
                }

                else {
                    side.getFullPic().setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Numbers_Thumbnail.png"))));
                }


            }
        });

        side.getStart().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (text.equals("[" + side.pets + "]")) {
                    side.getPicList().setDisable(true);
                    randomBlank();
                    PetsButtonsPane buttons = new PetsButtonsPane();
                    buttons.getButtonArray()[randomRow][randomCol].setGraphic(new ImageView(new Image(getClass().getResourceAsStream("BLANK.png"))));
                    pane.add(buttons,0,0,1,4);


                }

                else if (text.equals("[" + side.scenery + "]")) {
                    SceneryButtonsPane buttons = new SceneryButtonsPane();

                    randomBlank();
                    buttons.getButtonArray()[randomRow][randomCol].setGraphic(new ImageView(new Image(getClass().getResourceAsStream("BLANK.png"))));
                    pane.add(buttons,0,0,1,4);
                }

                else if (text.equals("[" + side.lego + "]")) {
                    LegoButtonsPane buttons = new LegoButtonsPane();
                    randomBlank();
                    buttons.getButtonArray()[randomRow][randomCol].setGraphic(new ImageView(new Image(getClass().getResourceAsStream("BLANK.png"))));
                    pane.add(buttons, 0, 0, 1, 4);
                }

                else {
                    NumbersButtonsPane buttons = new NumbersButtonsPane();
                    randomBlank();
                    buttons.getButtonArray()[randomRow][randomCol].setGraphic(new ImageView(new Image(getClass().getResourceAsStream("BLANK.png"))));
                    pane.add(buttons, 0, 0, 1, 4);

                    buttons.Swap(2,2);
                }


            }
        });




        getChildren().add(pane);


    }

    public SidePane getSide() {return side;}

    public void randomBlank() {
        randomRow = ThreadLocalRandom.current().nextInt(0, 4);
        randomCol = ThreadLocalRandom.current().nextInt(0, 4);
    }

}
