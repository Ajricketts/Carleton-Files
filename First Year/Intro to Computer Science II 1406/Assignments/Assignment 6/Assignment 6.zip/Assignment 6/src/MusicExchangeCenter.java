import javafx.util.Pair;

import java.util.*;

public class MusicExchangeCenter {

    private ArrayList<User> users;
    private ArrayList<Song> downloadedSongs;
    private HashMap<String, Float> royalties;
    private TreeSet<Song> tset;

    public MusicExchangeCenter() {
        users = new ArrayList<>();
        downloadedSongs = new ArrayList<>();
    }

    public ArrayList<Song> getDownloadedSongs() {return downloadedSongs;}

    public ArrayList<User> onlineUsers() {
        ArrayList<User> isOnline = new ArrayList<>();
        for (User u : users) {
            if (u.isOnline()) {
                isOnline.add(u);
            }
        }

        return isOnline;
    }

    public ArrayList<Song> allAvailableSongs() {
        ArrayList<Song> availableSongs = new ArrayList<>();

        for (User u : users) {
            if (u.isOnline()) {
                for (Song s : u.getSongList()) {
                    availableSongs.add(s);
                }
            }
        }

        return availableSongs;
    }

    @Override
    public String toString() {
        return "Music Exchange Center (" + onlineUsers().size() + " users on line, "
                + allAvailableSongs().size() + " songs available)";
    }

    public User userWithName(String s) {
        for (User u: users) {
            if (u.getUserName().equals(s)) {
                return u;
            }
        }

        return null;
    }

    public void registerUser(User x) {
        if (userWithName(x.getUserName()) == null) {
            users.add(x);
        }
    }

    public ArrayList<Song> availableSongsByArtist(String artist) {
        ArrayList<Song> artistSong = new ArrayList<>(), allSongs;

        allSongs = allAvailableSongs();

        for (Song s: allSongs) {
            if (s.getArtist().equals(artist)) {
                artistSong.add(s);
            }
        }

        return artistSong;
    }


    public Song getSong(String title, String ownerName) {
        for (User u: users) {
            if (u.getUserName().equals(ownerName) && u.isOnline()) {
                if (u.songWithTitle(title) != null) {
                    downloadedSongs.add(u.songWithTitle(title));
                }
                return u.songWithTitle(title);
            }
        }

        return null;
    }

    public void displayRoyalties() {
        System.out.println("Amount   Artist");
        System.out.println("----------------");
        ArrayList<String> artists = new ArrayList<>();
        HashMap<String, Integer> output = new HashMap<>();
        for (Song s: downloadedSongs) {
            artists.add(s.getArtist());
        }
        for(String b : artists){
            int count = Collections.frequency(artists, b);
            if(!(output.containsKey(b))){
                output.put(b, count);
            }
        }
        for(String v : output.keySet()){
            System.out.println("$" + String.format("%.02f", output.get(v) * 0.25) + "    " + String.format("%-9s", v));
        }
    }

    public TreeSet<Song> uniqueDownloads() {
        tset = new TreeSet<>(downloadedSongs);
        return tset;
    }

    public ArrayList<Pair<Integer, Song>> songsByPopularity() {
        ArrayList<Pair<Integer, Song>> temp = new ArrayList<>();
        ArrayList<Song> song = new ArrayList<>();
        for (Song s: downloadedSongs) {
            song.add(s);
        }

        for (Song t: song) {
            int count = Collections.frequency(song, t);
            if (!(temp.contains(t))) {
                temp.add(new Pair<>(count, t));
            }
        }
        ArrayList<Pair<Integer, Song>> popularSongs = new ArrayList<>();
        for (Pair<Integer, Song> p: temp) {
            if (!(popularSongs.contains(p))) {
                popularSongs.add(p);
            }
        }
        Collections.sort(popularSongs, new sortByKey());
        return popularSongs;
    }

    public class sortByKey implements Comparator<Pair<Integer, Song>>  {
        @Override
        public int compare(Pair<Integer, Song> p1, Pair<Integer, Song> p2) {
            return p2.getKey() - p1.getKey();
        }
    }
}
