import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class DVDButtonPane extends Pane {
    Button[] buttonList = new Button[3];
    public DVDButtonPane() {

        // Replace this with your own code
        Pane buttonPane = new Pane();

        Button Add = new Button("Add");
        //Add.relocate(95, 30);
        Add.setPrefSize(90, 30);
        Add.setStyle("-fx-font: 12 arial; -fx-base: GREEN; " +
               "-fx-text-fill: rgb(255,255,255);");
        buttonList[0] = Add;
        Button Delete = new Button("Delete");
        Delete.relocate(100, 0);
        Delete.setPrefSize(90, 30);
        Delete.setStyle("-fx-font: 12 arial; -fx-base: RED; " +
              "-fx-text-fill: rgb(255,255,255);");
        buttonList[1] = Delete;
        Button Stats = new Button("Stats");
        Stats.relocate(210, 0);
        Stats.setPrefSize(90, 30);
        Stats.setStyle("-fx-font: 12 arial; -fx-base: GREY; " +
              "-fx-text-fill: rgb(255,255,255);");
        buttonList[2] = Stats;

        buttonPane.getChildren().addAll(Add, Delete, Stats);

        getChildren().addAll(buttonPane);
    }


    public Button getAddButton() {return buttonList[0];}
    public Button getDeleteButton() {return buttonList[1];}
    public Button getStatsButton() {return buttonList[2];}
}
