import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.collections.FXCollections;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Insets;



public class DVDCollectionApp  extends Application {
    public void start(Stage primaryStage) {
        Pane  aPane = new Pane();

        // Create the labels
        // ... ADD CODE HERE ... //
        Label label = new Label("Title");
        Label label2 = new Label("Year");
        Label label3 = new Label("Length");


        // Create the lists
        String[]    titles = {"Star Wars", "Java is cool", "Mary Poppins", "The Green Mile"};
        String[]    years = {"1978", "2002", "1968", "1999"};
        String[]    lengths = {"124", "93", "126", "148"};
        // ... ADD CODE HERE ... //
        ListView<String> titlesList = new ListView<String>();
        titlesList.setItems(FXCollections.observableArrayList(titles));
        titlesList.relocate(10, 30);
        titlesList.setPrefSize(200, 150);

        ListView<String> yearsList = new ListView<String>();
        yearsList.setItems(FXCollections.observableArrayList(years));
        yearsList.relocate(230,30);
        yearsList.setPrefSize(60, 150);

        ListView<String> lengthsList = new ListView<String>();
        lengthsList.setItems(FXCollections.observableArrayList(lengths));
        lengthsList.relocate(300, 30);
        lengthsList.setPrefSize(60, 150);

        // Create the buttons
        // The following code shows how to set the font,
        // background color and text color of a button:
        // b.setStyle("-fx-font: 12 arial; -fx-base: rgb(0,100,0); " +
        // 	   "-fx-text-fill: rgb(255,255,255);");
        // ... ADD CODE HERE ... //
        Button Add = new Button("Add");
        Add.relocate(10, 210);
        Add.setPrefSize(95, 30);
        Add.setStyle("-fx-font: 12 arial; -fx-base: rgb(0,100,0); " +
                 	   "-fx-text-fill: rgb(255,255,255);");
        Button Delete = new Button("Delete");
        Delete.relocate(115, 210);
        Delete.setPrefSize(95, 30);
        Delete.setStyle("-fx-font: 12 arial; -fx-base: rgb(200,0,0); " +
                "-fx-text-fill: rgb(255,255,255);");
        Button Stats = new Button("Stats");
        Stats.setPrefSize(60, 30);
        Stats.relocate(300, 210);
        Stats.setStyle("-fx-font: 12 arial; -fx-base: rgb(200,200,200); " +
                "-fx-text-fill: rgb(255,255,255);");

        // Don’t forget to add the components to the window, set the title,
        // make it non-resizable, set Scene dimensions and then show the stage
        // ... ADD CODE HERE ... //
        aPane.getChildren().addAll(label, label2, label3, titlesList, yearsList,
                lengthsList, Add, Delete, Stats);

        primaryStage.setScene(new Scene(aPane, 360,240));
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
