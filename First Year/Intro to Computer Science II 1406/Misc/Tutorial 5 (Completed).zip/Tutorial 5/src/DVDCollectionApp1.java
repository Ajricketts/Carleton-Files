import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.collections.FXCollections;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Insets;



public class DVDCollectionApp1  extends Application {
    public void start(Stage primaryStage) {
        Pane  aPane = new Pane();

        // Create the labels
        // ... ADD CODE HERE ... //
        Label label = new Label("Title");
        label.relocate(10,10);
        Label label2 = new Label("Year");
        label2.relocate(230,10);
        Label label3 = new Label("Length");
        label3.relocate(300,10);

        // Create the lists
        String[]    titles = {"Star Wars", "Java is cool", "Mary Poppins", "The Green Mile"};
        String[]    years = {"1978", "2002", "1968", "1999"};
        String[]    lengths = {"124", "93", "126", "148"};
        // ... ADD CODE HERE ... //
        ListView<String> titlesList = new ListView<String>();
        titlesList.setItems(FXCollections.observableArrayList(titles));
        titlesList.relocate(10, 40);
        titlesList.setPrefSize(200, 150);

        ListView<String> yearsList = new ListView<String>();
        yearsList.setItems(FXCollections.observableArrayList(years));
        yearsList.relocate(230,40);
        yearsList.setPrefSize(60, 150);

        ListView<String> lengthsList = new ListView<String>();
        lengthsList.setItems(FXCollections.observableArrayList(lengths));
        lengthsList.relocate(300, 40);
        lengthsList.setPrefSize(60, 150);

        // Create the buttons
        // The following code shows how to set the font,
        // background color and text color of a button:
        // b.setStyle("-fx-font: 12 arial; -fx-base: rgb(0,100,0); " +
        // 	   "-fx-text-fill: rgb(255,255,255);");
        // ... ADD CODE HERE ... //
        DVDButtonPane dvdPane = new DVDButtonPane();
        dvdPane.relocate(30, 200);

        // Don’t forget to add the components to the window, set the title,
        // make it non-resizable, set Scene dimensions and then show the stage
        // ... ADD CODE HERE ... //
        aPane.getChildren().addAll(label, label2, label3, titlesList, yearsList,
                lengthsList, dvdPane);

        primaryStage.setTitle("My DVD Collection");
        primaryStage.setScene(new Scene(aPane, 360,230));
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
