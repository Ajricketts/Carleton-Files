import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.event.*;

public class DVDCollectionApp2  extends Application {
    private DVDCollection model;

    public void start(Stage primaryStage) {
        Pane  aPane = new Pane();

        // Create the labels
        Label label1 = new Label("DVDs");
        label1.relocate(10,10);
        Label label2 = new Label("Title");
        label2.relocate(10,202);
        Label label3 = new Label("Year");
        label3.relocate(10,242);
        Label label4 = new Label("Length");
        label4.relocate(120,242);

        // Create the TextFields
        TextField tField = new TextField();
        tField.setPrefSize(500,30);
        tField.relocate(50,200);
        TextField yField = new TextField();
        yField.setPrefSize(55,30);
        yField.relocate(50,240);
        TextField lField = new TextField();
        lField.setPrefSize(45, 30);
        lField.relocate(180,240);

        // Create the lists
        ListView<DVD>    tList = new ListView<DVD>();
        tList.setPrefSize(540,150);
        tList.relocate(10,40);
        DVD[] dvdCollectionDVDs = new DVD[model.getDvdCount()];
        for (int i = 0; i < model.getDvdCount(); i++) {
            dvdCollectionDVDs[i] = model.getDvds()[i];
        }
        tList.setItems(FXCollections.observableArrayList(dvdCollectionDVDs));
        // Create the buttons
        DVDButtonPane dvdPane = new DVDButtonPane();
        dvdPane.relocate(250, 240);
        dvdPane.getAddButton().setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                model.add(new DVD(tField.getText(), Integer.parseInt(yField.getText()), Integer.parseInt(lField.getText())));
                DVD[] dvdCollectionDVDs = new DVD[model.getDvdCount()];
                for (int i = 0; i < model.getDvdCount(); i++) {
                    dvdCollectionDVDs[i] = model.getDvds()[i];
                }
                tList.setItems(FXCollections.observableArrayList(dvdCollectionDVDs));
            }});

        dvdPane.getDeleteButton().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                model.remove(tList.getSelectionModel().getSelectedItem().getTitle());
                DVD[] dvdCollectionDVDs = new DVD[model.getDvdCount()];
                for (int i = 0; i < model.getDvdCount(); i++) {
                    dvdCollectionDVDs[i] = model.getDvds()[i];
                }
                tList.setItems(FXCollections.observableArrayList(dvdCollectionDVDs));
            }
        });
        // Add all the components to the window
        aPane.getChildren().addAll(label1, label2, label3, label4, tField, yField,
                lField, tList, dvdPane);

        primaryStage.setTitle("My DVD Collection");
        primaryStage.setResizable(false);
        primaryStage.setScene(new Scene(aPane, 548,268));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    public DVDCollectionApp2() {
        model = DVDCollection.example1();
    }
}
