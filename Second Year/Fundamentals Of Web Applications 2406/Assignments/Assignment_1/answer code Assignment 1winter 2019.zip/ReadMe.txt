2406 Assignment 1

(c) Louis D. Nel 2018

Last tested with: node.js v8.11.4 on Mac OSX High Sierra 10.13.6

Install: (Assumes node.js and npm are installed.)  No other NPM modules needed.

Launch:
node server.js

Testing: 
Use Chrome browser to visit:
http://localhost:3000/assignment1.html

Issues:

[FIXED] The mouse targeting is off if your browser window is small enough to put scroll bars on the canvas. That is, the mouse location does not compensate for a scrolled canvas in this app. -something to fix in the future.
