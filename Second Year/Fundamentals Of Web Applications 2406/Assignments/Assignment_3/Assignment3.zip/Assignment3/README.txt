Author: Alyxander-Jacob Ricketts
Student Id: 101084146
Email: aj.ricketts@carleton.ca

Node version: v10.15.0
Npm version: v6.4.1

Install: The only thing needed to install to run this app is node, npm and socket.io. Node.js can be downloaded at https://nodejs.org/en/.
          npm is packaged with Node.js. Socket.io can be installed by running npm install socket.io in the terminal.

Launch: To launch app, navigate to /Assignment-2 and run:   node server.js and follow the TO TEST instructions in the console
        (visit http://localhost:3000/Assignment2.html in browser)

Issues:
        - Was not able to implement socket.io capabilities
