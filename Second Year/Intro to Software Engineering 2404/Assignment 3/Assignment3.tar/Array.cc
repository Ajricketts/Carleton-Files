#include <iostream>
#include <iomanip>
using namespace std;

#include "Array.h"
#include "Course.h"

Array::Array(){
  size = 0; // Set the size to 0;
}

Array::~Array(){
  // Free all the memory
  for(int i=0; i < size; i++){
    delete elements[i];
  }
}

void Array::add(Course* c){
  if(size == 0){
    elements[size] = c;
    size++;
  }
  else{
    for(int i = 0; i < size; i++){

      if(c->lessThan(elements[i])){
        // Organize the courses from least to greatest
        Course *temp = elements[i];
        elements[i] = c;
        for(int j = i; j <= size; j++){
          Course *temp2 = elements[j+1];
          elements[j+1] = temp;
          temp = temp2;
        }
        break;
      }
      else if(!(c->lessThan(elements[i]))){
        // Organize the courses from least to greatest
        if(i == size-1){
          elements[size] = c;
        }
      }

    }
    size++;
  }
}

float Array::computeGPA() {
  float count = 0;
  float total = 0;
  float average = 0;

  // get the average of all the students marks. Get all the marks and total them up
  //  then divide that number by the number of courses that have not been withdrawn
  for(int i = 0; i < size; i++){
    int tempNum;
    tempNum = elements[i] -> getGrade();
    if (tempNum != -1) {
      total += tempNum;
      count++;
    }
  }

  average = total / count;

  return average;

}

int Array::computeNumFW() {
  int count = 0;
  int grade = 0;

  // Get the number of courses failed or withdrawn, if the grade was 0 or -1, increase the counter
  for(int i = 0; i < size; i++){
    grade = elements[i] -> getGrade();

    if (grade == 0 || grade == -1) {
      count++;
    }
  }

  return count; // Return the total of failed or withdrawn grades
}

void Array::print(){

  for(int i = 0; i < size; i++){
    elements[i]->print();
  }
}
