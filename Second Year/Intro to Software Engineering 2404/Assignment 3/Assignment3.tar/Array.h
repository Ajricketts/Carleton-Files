#include <string>
#include "Course.h"

using namespace std;

#define MAX_ARR_SIZE  128

class Array
{
  public:
    Array();
    ~Array();
    void add(Course*);
    void print();
    float computeGPA();
    int computeNumFW();

  private:
    int size;
    Course *elements[MAX_ARR_SIZE];
};
