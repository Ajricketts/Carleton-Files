#ifndef CONTROL_H
#define CONTROL_H

#include <vector>

#include "View.h"
#include "Storage.h"
#include "Monitor.h"
#include "GPAMonitor.h"

class Control
{
  public:
     Control();
     ~Control();
     void launch();
     void notify(Student* newStu);

  private:
    Storage storage;
    View view;
    vector<Monitor*> monitors;

};

#endif
