#ifndef GPAMONITOR_H
#define GPAMONITOR_H

#include "Monitor.h"
#include "Student.h"

class GPAMonitor : public Monitor
{
  public:
    GPAMonitor(float);
    void update(Student*);

  private:
    float minGPA;
};

#endif
