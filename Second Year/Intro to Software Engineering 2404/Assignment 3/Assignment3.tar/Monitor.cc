#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
using namespace std;

#include "Monitor.h"

Monitor::Monitor() {

}

void Monitor::update(Student*) {

}

void Monitor::printLogs() {

  for (int i = 0; i <collection.size(); i++) {
        cout << collection.at(i) << " " << endl; // Print the logs to the screen
    }
}
