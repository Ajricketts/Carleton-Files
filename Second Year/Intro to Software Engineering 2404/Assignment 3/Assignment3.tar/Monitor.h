#ifndef MONITOR_H
#define MONITOR_H

#include <vector>

#include "Student.h"

class Monitor {

  public:
    Monitor();
    virtual void update(Student*);
    void printLogs();

  protected:
    vector<string> collection;
};

#endif
