#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "Student.h"

Student::Student(int i)
{
  // Initialize all variables needed.
  id = i;
  numCourses = 0;
}

void Student::addCourse(Course* c)
{
  if (numCourses >= MAX_NUM_COURSES)
  {
      // check if the maximum number of courses has been reached
      //  and notify the user if it has
      cout << "Max number of courses reached" << endl;
      return;
  }
  courses.add(c); // add the course to the array
  ++numCourses; // increase the number of courses added
}

float Student::computeGPA() {
  float average;
  // Get the gpa of the student by using the function in the array class through delegation
  average = courses.computeGPA();
  return average;
}

int Student::computeNumFW() {
  int count;
  // Get the number of fails or withdrawns the student has by using the function in the
  //  array class through delegation
  count = courses.computeNumFW();
  return count;
}

int Student::getId() {
  return id; // Getter for the Id
}

void Student::print()
{
  string gpa = to_string(computeGPA());
  cout<< endl << "Id: " << id << endl;
  courses.print();// Print each course out to the console using the print
                           //   function in the courses class
  cout << "GPA: " + gpa << endl;
}
