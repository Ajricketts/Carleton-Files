#ifndef STUDENT_H
#define STUDENT_H

#include "defs.h"
#include "Course.h"
#include "Array.h"

class Student
{
  public:
    Student(int=0);
    void print();
    void addCourse(Course*);
    float computeGPA();
    int computeNumFW();
    int getId();

  private:
    int    id;
    Array courses;
    int    numCourses;
};

#endif
