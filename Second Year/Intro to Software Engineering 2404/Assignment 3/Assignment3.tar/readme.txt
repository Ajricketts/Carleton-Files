Author: Alyxander-Jacob Ricketts     101084146

Purpose: The purpose of this program is to build a student auditing system
         that allows the user to add new students all with varying student ID's,
         courses, grades, and instructors. It has now been revised an updated to
         add a monitoring system, to monitor the GPA's of the students as well as
         the amounts of fails and withdraws they have. As well as implementing a
         new collection class

Source / Header / Data Files: Control.cc View.cc main.cc Student.cc Course.cc Storage.cc
                              Array.cc Monitor.cc GPAMonitor.cc FWMonitor.cc

Compilation: to compile this program, navigate to the directory with all the source /
             header / data files in the terminal and run the "make" command

Launching: To launch the program, once compiled, a "sas" executible will be created
           type the ./sas command in your terminal to run the program.

Operating Instructions: Once the program is launched, follow the instructions on the
                        menu that is printed to the console to add new students to the
                        system.
