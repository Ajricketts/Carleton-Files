#include <string>
#include "Course.h"

using namespace std;

#define MAX_ARR_SIZE  128

template <class T>
class Array
{
  public:
    Array(){
      size = 0; // Set the size to 0;
    }

    ~Array(){
      // Free all the memory
      for(int i=0; i < size; i++){
        delete elements[i];
      }
    }

    void operator +=(Course* c){
      if(size == 0){
        elements[size] = c;
        size++;
      }
      else{
        for(int i = 0; i < size; i++){

          if(c->lessThan(elements[i])){
            // Organize the courses from least to greatest
            Course *temp = elements[i];
            elements[i] = c;
            for(int j = i; j <= size; j++){
              Course *temp2 = elements[j+1];
              elements[j+1] = temp;
              temp = temp2;
            }
            break;
          }
          else if(!(c->lessThan(elements[i]))){
            // Organize the courses from least to greatest
            if(i == size-1){
              elements[size] = c;
            }
          }

        }
        size++;
      }
    }

    void print(){

      for(int i = 0; i < size; i++){
        elements[i]->print();
      }
    }

  protected:
    int size;
    Course *elements[MAX_ARR_SIZE];
};
