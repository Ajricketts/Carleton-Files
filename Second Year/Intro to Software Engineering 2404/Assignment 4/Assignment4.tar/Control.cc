#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <iomanip>
using namespace std;

#include "Control.h"
#include "Course.h"
#include "Student.h"
#include "Storage.h"
#include "View.h"
#include "GPAMonitor.h"
#include "FWMonitor.h"

Control::Control()
{

  GPAMonitor* g = new GPAMonitor(3.0); // dynamically create a new GPAMonitor object with a min bound of 3.0
  FWMonitor* f = new FWMonitor(2); // dynamically create a new FWMonitor object with a max bound of 2
  monitors.push_back(g); // Add both of these objects to the collection of monitors
  monitors.push_back(f);


  stringstream ss;
  vector<string> studentVect;
  stuServer.retrieve(studentVect); //Retrieve the students from the cloud service
  int numStu = 0;

  //Loop through the students
  for (int i = 0; i < studentVect.size(); i++) {
    Student* tempStu;
    Course*  tempCourse;
    int      stuId, courseCode, grade, term;
    string   instructor;
    ss.clear(); // Clear the string stream
    ss.str(studentVect[i]);

    ss >> stuId;
    tempStu = new Student(stuId); // create a new student
    ss >> courseCode;
    // Loop till there are no more courses to add
    while (courseCode != 0) {
      ss >> term;
      ss >> grade;
      ss >> instructor;

      //Create a new course with the information gathered from the user
      tempCourse = new Course(courseCode, grade, term, instructor);
      *tempStu +=(tempCourse); // Add this course to the student

      ss >> courseCode;
    }

    storage +=(tempStu);
    notify(tempStu); // call the notify function for this student
    ++numStu;
  }


  if (numStu > 0) {
    // If there are students, print them to the screen
    storage.print();
  }
}

void Control::notify(Student* newStu) {
  // Loop through each of the monitor objects and call their update functions
  for (int i = 0; i < monitors.size(); i++) {
    monitors[i] -> update(newStu);
  }
}

void Control::launch()
{
  Student* tempStu;
  Course*  tempCourse;
  int      numStu, menuSelection;
  int      courseResponse;
  int      stuId, courseCode, grade, term;
  string   instructor;

  while (1) {
    menuSelection = view.mainMenu(); // Recieve the users selection

    if (menuSelection == 0){
      // If there selection is 0, end the program
      break;
    }

    else if (menuSelection == 1) {
      // If their selection is 1 get all the information to add a student to storage
      stuId = view.readId(); // get the student ID
      tempStu = new Student(stuId); // create a new student
      while (1)
      {
        // Get the course information, continue looping and adding new courses
        //  unless the user enters 0 as the course code
        courseResponse = view.readCourse(&courseCode, &grade, &term, &instructor);

        if (courseResponse == 0)
        {
          // If the user enters 0 as the course code, break
          break;
        }

        // Create a new course with the information gathered from the user
        tempCourse = new Course(courseCode, grade, term, instructor);
        *tempStu +=(tempCourse); // Add this course to the student
      }

    }

    // Add the student to storage
    storage +=(tempStu);
    notify(tempStu); // call the notify function for this student
    ++numStu;
  }

    if (numStu > 0) {
      // If there are students, print them to the screen
      storage.print();
    }
}

Control::~Control() {

  // Print out the logs to the screen
  cout << endl << "##############################" << endl;
  cout << "              LOGS            " << endl;
  cout << "##############################" << endl;
  for (int i = 0; i < monitors.size(); i++) {
    monitors[i] -> printLogs();
  }

  // Free all the memory allocated for the monitor collections
  for (int i = 0; i < monitors.size(); i++) {
    delete monitors[i];
  }
}
