#ifndef CONTROL_H
#define CONTROL_H

#include <vector>

#include "View.h"
#include "Storage.h"
#include "Monitor.h"
#include "GPAMonitor.h"
#include "StuServer.h"

class Control
{
  public:
     Control();
     ~Control();
     void launch();
     void notify(Student* newStu);

  private:
    Storage storage;
    StuServer stuServer;
    View view;
    vector<Monitor*> monitors;

};

#endif
