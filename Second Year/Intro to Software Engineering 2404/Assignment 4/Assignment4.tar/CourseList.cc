#include <iostream>
using namespace std;
#include <string>
#include <iomanip>

#include "CourseList.h"

CourseList::CourseList() {

}

CourseList::~CourseList() {

}

float CourseList::computeGPA() {
  float count = 0;
  float total = 0;
  float average = 0;

  // get the average of all the students marks. Get all the marks and total them up
  //  then divide that number by the number of courses that have not been withdrawn
  for(int i = 0; i < size; i++){
    int tempNum;
    tempNum = elements[i] -> getGrade();
    if (tempNum != -1) {
      total += tempNum;
      count++;
    }
  }

  average = total / count;

  return average;

}

int CourseList::computeNumFW() {
  int count = 0;
  int grade = 0;

  // Get the number of courses failed or withdrawn, if the grade was 0 or -1, increase the counter
  for(int i = 0; i < size; i++){
    grade = elements[i] -> getGrade();

    if (grade == 0 || grade == -1) {
      count++;
    }
  }

  return count; // Return the total of failed or withdrawn grades
}
