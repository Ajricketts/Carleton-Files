#include <string>
#include "Course.h"
#include "Array.h"

using namespace std;

class CourseList: public Array<Course*>
{
  public:
    CourseList();
    ~CourseList();
    float computeGPA();
    int computeNumFW();

};
