#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
using namespace std;

#include "FWMonitor.h"

FWMonitor::FWMonitor(int m) : Monitor() {
  maxFW = m;
}

void FWMonitor::update(Student* stu) {
  int compare = stu -> computeNumFW(); // have the number of fails or withdrawns as an int in order to be able to
                                      //  compare it to the max # of F or WDN

  string fw = to_string(stu -> computeNumFW()); // Convert the # F or WDN to a string
  string id = to_string(stu -> getId()); // Convert the id to a string

  string Log = "ID: " + id + "  Number of FW: " + fw; // create the log

  if (compare > maxFW) {
    collection.push_back(Log); // Add it to the collection
  }
}
