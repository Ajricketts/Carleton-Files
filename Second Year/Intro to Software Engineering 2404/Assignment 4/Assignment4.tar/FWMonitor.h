#ifndef FWMONITOR_H
#define FWMONITOR_H

#include "Monitor.h"
#include "Student.h"

class FWMonitor : public Monitor
{
  public:
    FWMonitor(int);
    void update(Student*);

  private:
    float maxFW;
};

#endif
