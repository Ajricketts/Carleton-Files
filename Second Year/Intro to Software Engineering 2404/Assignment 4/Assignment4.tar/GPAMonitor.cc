#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
using namespace std;

#include "GPAMonitor.h"

GPAMonitor::GPAMonitor(float m) : Monitor() {
  minGPA = m; // set the threshold for gpa
}

void GPAMonitor::update(Student* stu) {
  int compare = stu -> computeGPA(); // have the gpa as an int in order to be able to compare it to the min gpa

  string gpa = to_string(stu -> computeGPA()); // Convert the gpa to a string
  string id = to_string(stu -> getId()); // Convert the id to a string

  string Log = "ID: " + id + "  GPA: " + gpa; // create the log

  if (compare < minGPA) {
    collection.push_back(Log); // Add it to the collection
  }
}
