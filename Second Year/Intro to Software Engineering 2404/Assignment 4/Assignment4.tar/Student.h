#ifndef STUDENT_H
#define STUDENT_H

#include "defs.h"
#include "Course.h"
#include "CourseList.h"

class Student
{

  public:
    Student(int=0);
    void print();
    float computeGPA();
    int computeNumFW();
    void operator+=(Course*);
    int getId();

  private:
    int    id;
    CourseList courses;
    int    numCourses;
};

#endif
