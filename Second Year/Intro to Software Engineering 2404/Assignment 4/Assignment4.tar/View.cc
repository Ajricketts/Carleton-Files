#include <iostream>
using namespace std;
#include <string>

#include "View.h"
#include "Course.h"
#include "Student.h"
#include "Storage.h"

int View::mainMenu()
{
  // Display the main Menu
  int numOptions = 1;
  int selection  = -1;

  cout << endl;
  cout << "(1) Add student" << endl;
  cout << "(0) Exit" << endl;

  // Get the selection from the user
  while (selection < 0 || selection > numOptions) {
    cout << "Enter your selection: ";
    cin  >> selection;
  }

  return selection;
}

int View::readId()
{
  // Get the student id from the user and return it
  int stuId;
  cout << "student id:   ";
  cin  >> stuId;
  return stuId;
}

int View::readCourse(int* courseCode, int* grade, int* term, string* instructor)
{
  // Read all the course info
  int response;
  int     numCourses;
  numCourses = 0;

  cout << "course code <0 to end>:  ";
  cin  >> *courseCode; // Read the course code
  if (*courseCode == 0)
  {
    response = 0;
    return response;
  }

  else {response = 1;}

  cout << "grade:                   ";
  cin  >> *grade; // Read the grade

  cout << "Term Taken (In the format of YYYYTT):                 ";
  cin >> *term; // Read the term

  cout << "Instructor:                 ";
  cin >> *instructor; // Read the instructor

  return response;
}

void View::print(Storage& s)
{
  s.print(); // Print through delegation
}
