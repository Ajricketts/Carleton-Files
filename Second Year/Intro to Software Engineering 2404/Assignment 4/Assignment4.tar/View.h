#ifndef VIEW_H
#define VIEW_H

#include "Student.h"
#include "Storage.h"

class View
{
  public:
    int mainMenu();
    int readId();
    int readCourse(int* courseCode, int* grade, int* term, string* instructor);
    void print(Storage& s);

};

#endif
