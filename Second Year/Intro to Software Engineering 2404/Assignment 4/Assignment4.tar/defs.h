#ifndef DEFS_H
#define DEFS_H

#define MAX_NUM_STU     256
#define MAX_NUM_COURSES  64

#endif

