#include <iostream>
using namespace std;
#include <string>

#include "defs.h"
#include "Control.h"

int  mainMenu();


int main()
{
  Control c;
  c.launch();
}
