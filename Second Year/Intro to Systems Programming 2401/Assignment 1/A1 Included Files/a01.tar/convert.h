/* file is convert.h 
 *
 *   copyright Doron Nussbaum 2018
 *   do not distribute 
 *
 * */

int convert(int num, int base); 


