Author: Alyxander-Jacob Ricketts

Purpose: A program that allows you to enter a message to encrypt. The encryption proccess involves charecter shifting using a key (Caesar Cypher), cicular rotation, and an xor operation. 

List of Source Files: encrypt.c, bit_manipulation.h, bit_manipulation.c, encryptReadMe.txt

Compilation Command: gcc -o encrypt encrypt.c bit_manipulation.c

Launching and operating instructions: Compile the code using the compilation command above in terminal. Using the program type in the message you wish to encrypt. Then put in the key (the amount you want to shift the charecters by) and the output will be your encrypted message.  	

Example: Input this into the encrypt function: "This was a fun assignment"
					       The output should be: 10 -76 -58 34 -6 8 80 -99 -104 -79 59 81 47 2 1 47 -14 37 65 -92 110 -75 6 112 51
