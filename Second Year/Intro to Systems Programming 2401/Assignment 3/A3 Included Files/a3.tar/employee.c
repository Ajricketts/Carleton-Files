// file is person.c

/*
Purpose: contains the functions for processing employree records



Revisions:
11/2018 - Doron Nussbaum 	Created




Copyright 2018 Doron Nussbaum


*/



/******************************************************/
// include files 


#include "stdio.h"
#include "employee.h"



/******************************************************/

void printEmployee(PersonRec *person)

{
	char s[256];

	return;
}
