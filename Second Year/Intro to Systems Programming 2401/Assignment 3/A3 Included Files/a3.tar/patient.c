/*
File name is patient.c
Purpose: file contains a function for processing patient records

Revisions
11/2018 - Doron Nussbaum created 





Copyright 2018 Doron Nussbaum

*/

/******************************************************************/
// INCLUDE 



#include "string.h"
#include "stdio.h"
#include "patient.h"


/*****************************************************************/

void printPatient(PersonRec *person)

{
	char s[256];

}


