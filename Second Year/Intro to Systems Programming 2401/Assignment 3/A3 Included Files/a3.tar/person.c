// file is person.c

/*
Purpose: contains the functions for processing person records



Revisions:
11/2018 - Doron Nussbaum 	Created




Copyright 2018 Doron Nussbaum


*/



/******************************************************/
// include files 


/******************************************************/
// function prototypes

