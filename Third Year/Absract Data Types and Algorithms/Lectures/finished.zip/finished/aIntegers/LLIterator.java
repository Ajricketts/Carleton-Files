package finished.aIntegers;

public interface LLIterator {
    int getNext();
    boolean hasNext();
}
