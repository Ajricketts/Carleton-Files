package finished.aIntegers;

public class Node{
    int x;          //data
    Node next;
    public Node(int x){
        this.x = x;
    }
}