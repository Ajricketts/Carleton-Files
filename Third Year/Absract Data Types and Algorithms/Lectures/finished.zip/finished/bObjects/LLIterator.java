package finished.bObjects;

public interface LLIterator {
    Object getNext();
    boolean hasNext();
}
