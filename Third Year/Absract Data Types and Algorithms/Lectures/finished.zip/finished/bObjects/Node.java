package finished.bObjects;

public class Node{
    Object x;          //data
    Node next;
    public Node(Object x){
        this.x = x;
    }
}