package finished.cGenerics;

public interface LLIterator<T> {
    T getNext();
    boolean hasNext();
}
