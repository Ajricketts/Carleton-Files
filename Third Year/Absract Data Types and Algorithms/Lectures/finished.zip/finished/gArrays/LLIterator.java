package finished.gArrays;

public interface LLIterator<T> {
    T getNext();
    boolean hasNext();
}
