package finished.zPuzzle;

public class BinaryTreeNode<Node extends BinaryTreeNode<Node>> {
    Node parent, leftchild, rightchild;
}
