package finished.zPuzzle;

public class DataNode<T> extends BinaryTreeNode {
    T data;
}
